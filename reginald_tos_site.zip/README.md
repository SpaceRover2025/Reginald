# Reginald Terms of Service

This is a simple static website containing the Terms of Service for the Discord bot **Reginald**.

## Hosting on GitHub Pages

1. Create a new GitHub repository named `reginald-tos`.
2. Clone the repo:
   ```bash
   git clone https://github.com/yourusername/reginald-tos.git
   ```
3. Copy the contents of this folder into the cloned repo.
4. Commit and push:
   ```bash
   git add .
   git commit -m "Add Terms of Service site"
   git push origin main
   ```
5. In your repository settings, enable GitHub Pages on the `main` branch.

Your site will be live at `https://yourusername.github.io/reginald-tos/`.
